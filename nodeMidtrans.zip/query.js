const wrapper = require('./helpers/utils/wrapper');
// const config = require('./config');
const Mysql = require('./helpers/databases/mysql/db');

const generateInvoiceNumber = async () => {
    const db = new Mysql();
    const query = `SELECT * FROM mnr01 where code = 'INVENS'`;
    const result = await db.query(query);
    if (result.err) {
        return wrapper.error('fail', 'cannot query', 500)
    }
    return wrapper.data(result.data, 'success', 200);
};

const cekInvoiceNumber = async (params) => {
    const db = new Mysql();
    const query = `SELECT * FROM tph01 where invoice_number = '${params}' order by id desc`;
    const result = await db.query(query);
    if (result.err) {
        return wrapper.error('fail', 'cannot query', 500)
    }
    return wrapper.data(result.data, 'success', 200);
};

const InvoiceItemUpdate = async (_) => {
    const { invoice, orderId } = _;
    const db = new Mysql();
    const query = `UPDATE tpi01 SET invoice_number = '${invoice}' WHERE tph01_id = '${orderId}'`;
    const result = await db.query(query);
    if(result.err){
        return wrapper.error(result.err, 'cannot update', 500)
    }
    return wrapper.data('Success update');
};

module.exports = {
    generateInvoiceNumber,
    cekInvoiceNumber,
    InvoiceItemUpdate
}
