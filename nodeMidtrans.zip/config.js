require('dotenv').config();
const confidence = require('confidence');

const config = {
    mysqlConfig: {
        connectionLimit : 100,
        host     : "klob.cvb5deiylign.ap-southeast-1.rds.amazonaws.com",
        user     : "development",
        password : "P@ssw0rd",
        port     : 3306,
        database : "pgdb"
    }
};

const store = new confidence.Store(config);

exports.get = (key) => store.get(key);
